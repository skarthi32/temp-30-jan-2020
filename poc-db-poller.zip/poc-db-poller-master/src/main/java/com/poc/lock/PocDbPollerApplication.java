package com.poc.lock;

import com.poc.lock.entity.PollRecord;
import com.poc.lock.poller.DelayPoller;
import com.poc.lock.repository.PollerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

@SpringBootApplication
public class PocDbPollerApplication implements CommandLineRunner {

    @Autowired
    private DelayPoller poller;
    @Autowired
    private PollerRepository repository;

    public static void main(String[] args) {
        SpringApplication.run(PocDbPollerApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            insertData();
            System.out.println("No Of Records:" + repository.countByValueIsNotNull().longValue());

            Future<List<PollRecord>> f1 = doPoll();
            Future<List<PollRecord>> f2 = doPoll();

            List<Long> foundIds = new ArrayList<>();

            List<PollRecord> p1 = f1.get();
            foundIds.addAll(p1.stream()
                    .map(PollRecord::getId)
                    .collect(Collectors.toList()));

            List<PollRecord> p2 = f2.get();
            foundIds.addAll(p2.stream()
                    .map(PollRecord::getId)
                    .collect(Collectors.toList()));


            System.out.println("Size should be 20: " + foundIds.size());

            List<Long> duplicateIds = foundIds.stream()
                    .filter(foundId -> Collections.frequency(foundIds, foundId) > 1)
                    .collect(Collectors.toList());
            System.out.println("Duplicate is not available?: " + duplicateIds.isEmpty());
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            new CountDownLatch(1).await();
        }

    }

    private void insertData() {
        for (int i = 0; i < 20; i++) {
            repository.save(PollRecord.builder().value(UUID.randomUUID().toString()).build());
        }
    }

    Future<List<PollRecord>> doPoll() {
        return CompletableFuture.supplyAsync(() -> poller.getNextPollCycle());
    }
}
